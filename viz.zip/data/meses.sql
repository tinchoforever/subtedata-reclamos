use test;
select  distinct s.hora as hora, z.mes, x.symbol, x.estacion
from subtes_01 as s
LEFT join (
select distinct b.mes as mes
from subtes_01 as b) as z on (1=1)
LEFT join (select distinct
	REPLACE(linea,'LINEA_','') as symbol,
    estacion
	from subtes_01 as c 
    where linea like 'LINEA_%'
) as x on (1=1) ;