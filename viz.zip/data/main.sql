use test;
select 
	CONCAT(hora,':00:00') as 'date',
    REPLACE(linea,'LINEA_','') as symbol, 
    round(avg(total)) as price 
from subtes_01
where linea like 'LINEA_%'
group by linea, hora;