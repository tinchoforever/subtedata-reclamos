use test;
select 
    CONCAT(hora,':00:00') as d,
    REPLACE(linea,'LINEA_','') as symbol, 
    sum(total) as price 
from subtes_01
where linea like 'LINEA_%'
group by linea, hora;
